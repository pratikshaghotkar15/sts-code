package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringJdbcController {
	@Autowired
	JdbcTemplate jdbc;
	
	@RequestMapping("/")
	public String test() {
		return "type correct url";
	}
	
	@RequestMapping("/addStudent")
	public String adst() {
		jdbc.execute("insert into student2(rollno,sname,classname) values(112,'pratiksha','BE');");
		jdbc.execute("insert into student2(rollno,sname,classname) values(113,'appi','Bcom');");
		jdbc.execute("insert into student2(rollno,sname,classname) values(114,'mayur','BEd');");
		jdbc.execute("insert into student2(rollno,sname,classname) values(115,'aniket','llb');");
		return "data saved";
	}
	
	@RequestMapping("/updateStudent")
	public String upst() {
		jdbc.execute("update student2 set sname='shreyash' where rollno=113");
		return "data updated";
	}
	
	@RequestMapping("/deleteStudent")
	public String delst() {
		jdbc.execute("delete from student2 where rollno=115");
		return "data deleted";
	}
	
	

}
