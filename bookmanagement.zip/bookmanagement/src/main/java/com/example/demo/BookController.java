package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;





@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class BookController {
	//@Autowired
	//private BookService bookservice;
	
	@Autowired
	private BookRepository bookRepository;
	
	@PostMapping("/books")
	public Book createBook(@RequestBody Book book) {
		return bookRepository.save(book);
	}
	
	@GetMapping("/books")
	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}
	
	@DeleteMapping("/books/{bookId}")
	public void deleteBook(@PathVariable("bookId")long bookId) {
		this.bookRepository.deleteById(bookId);
	}
	
	//@PutMapping("/books/{bId}")
	//public Book updateBook(@RequestBody Book book,@PathVariable("bId")int bId)
	//{
		//return this.bookservice.updateBook(book,bId);
		
	//}
	
	
	//@GetMapping("/books/{id}")
	//public Book getBookById(@PathVariable("id") Long studentId) {
		//return bookRepository.getById(studentId);
	//}
	
	@GetMapping("/books/{id}")
	public ResponseEntity<Book> getStudentById(@PathVariable(value = "id") Long bookId)
			throws ResourceNotFoundException {
		Book book = bookRepository.findById(bookId)
				.orElseThrow(() -> new ResourceNotFoundException("book not found for this id :: " + bookId));
		return ResponseEntity.ok().body(book);
	}
	
	@PutMapping("/books/{id}")
	public ResponseEntity<Book> updateBook(@PathVariable(value = "id") Long bookId,
			@RequestBody Book bookDetails) throws ResourceNotFoundException {
		Book book = bookRepository.findById(bookId)
				.orElseThrow(() -> new ResourceNotFoundException("book not found for this id :: " + bookId));

		book.setBookName(bookDetails.getBookName());
		book.setAuthorName(bookDetails.getAuthorName());
		book.setBookId(bookDetails.getBookId());
		final Book updatedBook = bookRepository.save(book);
		return ResponseEntity.ok(updatedBook);
	}



}
