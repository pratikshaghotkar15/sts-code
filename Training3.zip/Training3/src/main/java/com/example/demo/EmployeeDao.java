package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
@Component
public class EmployeeDao {
	@Autowired
	private JdbcTemplate jdbc;

	public JdbcTemplate getJdbc() {
		return jdbc;
	}

	public void setJdbc(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}
	
	public int addEmployee(Employee emp) {
		String sql="insert into employee(id,name,email,password) values"+"("+emp.getId()+",'"+emp.getName()+"','"+emp.getEmail()+"','"+emp.getPassword()+"')";
		
		return jdbc.update(sql);
	}
	
	public int editEmployee(Employee emp) {
		String sql="update employee set name='"+emp.getName()+"',Email='"+emp.getEmail()+"',password='"+emp.getPassword()+"' where id="+emp.getId()+"";
		return jdbc.update(sql);
	}
	@SuppressWarnings("deprecation")
	public Employee getEmployeeById(int id) {
		String sql="select * from employee where id=?";
		return jdbc.queryForObject(sql,new Object[]{id},new BeanPropertyRowMapper<Employee>(Employee.class));
	}

	public int deleteEmployee(int id) {
		String sql="delete from employee where id="+id+"";
		return jdbc.update(sql);		
	}
	
	public List<Employee> getAllEmployee(){
		return jdbc.query("select * from employee",new RowMapper<Employee>(){
			public Employee mapRow(ResultSet rs,int row) throws SQLException{
				Employee e=new Employee();
				
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setEmail(rs.getString(3));
				e.setPassword(rs.getString(4));
				
				return e;
				
				
			}
		});
	}
	
}
