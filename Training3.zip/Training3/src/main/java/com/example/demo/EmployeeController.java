package com.example.demo;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class EmployeeController {
    @Autowired
	EmployeeDao empdao;
    
    @GetMapping("/emp")
    public String getAllEmployee(Model m) {
    	List<Employee> list=empdao.getAllEmployee();
    	m.addAttribute("emp", list);
    	return "emp-list";
    	
    }
    
    @GetMapping("/emp/add")
    public String getEmployeeForm(Model m) {
    	Employee emp=new Employee();
    	m.addAttribute("emp",emp);
    	return "emp-form";
    }
    
    @PostMapping("/emp/add")
    public String addEmployee(@ModelAttribute("addEmployee")Employee emp) {
    	empdao.addEmployee(emp);
    	return "emp-list";
    }
    
    @GetMapping("/emp/edit/{id}")
    public String editEmployee(@PathVariable("id")int id,Model m) {
    	Employee emp=empdao.getEmployeeById(id);
    	m.addAttribute("editEmployee", emp);
    	return "emp-edit-form";
    }
    
	@PostMapping("/emp/edit/{id}")
	public String updateEmployee(@ModelAttribute("editEmployee")Employee emp) {
		empdao.editEmployee(emp);
		return "emp-list";
	}
	
	@GetMapping("/emp/delete/{id}")
	public String deleteEmployee(@PathVariable("id")int id) {
		empdao.deleteEmployee(id);
		return "emp-list";
	}
	
}
