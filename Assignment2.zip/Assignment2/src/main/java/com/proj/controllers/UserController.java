package com.proj.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.proj.model.User;
import com.proj.repo.UserRepository;



@RestController
public class UserController {
	
    @Autowired
	private UserRepository userRepository;
    
	@RequestMapping("/hello")
	public String hello() {
		return "hello world";
	}
	
	@GetMapping(value="/callclient")
	private String getClientCall() {
		String uri="http://localhost:8080/hello";
		RestTemplate restTemplate=new RestTemplate();
		String result=restTemplate.getForObject(uri,String.class);
		return result;
	}
	
	@GetMapping(value="/genders")
	public User getDetails() {
		String uri="https://api.genderize.io/?name=peter";
		RestTemplate restTemplate=new RestTemplate();
		User result=restTemplate.getForObject(uri,User.class);
		userRepository.save(result);
		return result;
	}
}
