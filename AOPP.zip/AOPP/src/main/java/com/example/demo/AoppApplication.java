package com.example.demo;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


@SpringBootApplication
public class AoppApplication {

	public static void main(String[] args) {
		//ConfigurableApplicationContext context=SpringApplication.run(AoppApplication.class, args);
		ApplicationContext context=new ClassPathXmlApplicationContext("com/example/demo/config.xml");
		
		PaymentServiceImpl p=context.getBean(PaymentServiceImpl.class);
		p.makepayment();
		

	}

}
