package com.example.demo;

public interface PaymentService {
	
	public void makepayment();

}
