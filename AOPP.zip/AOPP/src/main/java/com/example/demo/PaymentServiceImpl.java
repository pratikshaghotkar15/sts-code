package com.example.demo;

public class PaymentServiceImpl implements PaymentService{

	@Override
	public void makepayment() {
		// TODO Auto-generated method stub
		
		System.out.println("amount debited");
		System.out.println("amount credited");
		
	}

}
