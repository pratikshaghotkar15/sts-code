package com.example.demo;

//@Aspect
public class MyAspect {

}
