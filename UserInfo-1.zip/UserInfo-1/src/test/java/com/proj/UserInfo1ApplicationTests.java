package com.proj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserInfo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
