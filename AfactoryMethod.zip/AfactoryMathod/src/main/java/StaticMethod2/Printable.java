package StaticMethod2;

public interface Printable {
	void print();
	

}
