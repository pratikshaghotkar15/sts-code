package StaticMethod2;

public class PrintableFactory {
	public static Printable getPrintable() {
		return new B();
	}

}
