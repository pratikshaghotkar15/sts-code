package StaticMethod2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("config.xml");
		//PrintableFactory p=context.getBean("p",PrintableFactory.class);
		
		Printable p=context.getBean("p",Printable.class);
		p.print();
		

	}

}
