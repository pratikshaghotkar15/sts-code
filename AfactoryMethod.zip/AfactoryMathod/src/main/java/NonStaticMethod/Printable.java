package NonStaticMethod;

public interface Printable {
	void print();
	

}
