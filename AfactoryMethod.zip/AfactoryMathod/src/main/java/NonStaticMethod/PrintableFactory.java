package NonStaticMethod;

public class PrintableFactory {
	
	public Printable getPrintable() {
		return new A();
	}

}
