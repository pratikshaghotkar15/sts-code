package NonStaticMethod;

public class A implements Printable {

	public void print() {
		// TODO Auto-generated method stub
		System.out.println("hello a");
		
	}
	

}
