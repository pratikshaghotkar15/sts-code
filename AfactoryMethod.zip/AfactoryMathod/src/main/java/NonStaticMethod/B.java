package NonStaticMethod;

public class B implements Printable{

	public void print() {
		// TODO Auto-generated method stub
		System.out.println("hello b");
		
	}

}
