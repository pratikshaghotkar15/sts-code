package com.example.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;

import com.example.demo.sevices.CustomProductDetailService;

@Configuration
@EnableWebSecurity
public class MySecurityConfig extends WebSecurityConfigurerAdapter {
	
	
	@Autowired
	private CustomProductDetailService customproductdetailservice;
	
	@Override
	protected void configure(HttpSecurity http) throws Exception{
		http
		
		//.csrf().disable()
		.csrf().csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
		.and()
		.authorizeRequests()
		//.antMatchers("/home","/login","/register").permitAll()
		//.antMatchers("/public/**").permitAll()
		.antMatchers("/signin").permitAll()
		.antMatchers("/public/**").hasRole("NORMAL")
		.antMatchers("/test1/**").hasRole("ADMIN")
		.anyRequest()
		.authenticated()
		.and()
		//.httpBasic();
		.formLogin()
		.loginPage("/signin")
		.loginProcessingUrl("/doLogin")
		.defaultSuccessUrl("/test1/");
		
		
	}
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception{
		//auth.inMemoryAuthentication().withUser("john").password(this.passwordEncoder().encode("durgesh")).roles("NORMAL");
		//auth.inMemoryAuthentication().withUser("roshni").password(this.passwordEncoder().encode("abc")).roles("ADMIN");
		
		auth.userDetailsService(customproductdetailservice).passwordEncoder(passwordEncoder());
		
	}
	
	//Role-High Level Overview => normal :Read
	//Authority - permission->Read
	//Admin -Read write update
	
	//@Bean
	//public PasswordEncoder passwordEncoder() {
		//return NoOpPasswordEncoder.getInstance();
		//return new BCryptPasswordEncoder(10);
	//}
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		//return NoOpPasswordEncoder.getInstance();
		return new BCryptPasswordEncoder(10);
	}
	
	

}
