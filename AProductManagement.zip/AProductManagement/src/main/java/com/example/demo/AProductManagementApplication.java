package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.example.demo.models.Product;
import com.example.demo.repo.ProductRepository;

@SpringBootApplication
public class AProductManagementApplication implements CommandLineRunner  {
    @Autowired
	private ProductRepository productRepository;
    
    @Autowired
    private BCryptPasswordEncoder bcryptpasswordencoder;
    
    
	public static void main(String[] args) {
		SpringApplication.run(AProductManagementApplication.class, args);
	}


	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Product product=new Product();
		product.setPid(1);
		product.setPname("oil");
		product.setQuantity(2);
		product.setPrice(430);
		product.setRole("ROLE_ADMIN");
		product.setUsername("roshni");
		product.setPwd(this.bcryptpasswordencoder.encode("abc"));
		this.productRepository.save(product);
		
		Product product1=new Product();
		product1.setPid(2);
		product1.setPname("soap");
		product1.setQuantity(10);
		product1.setPrice(150);
		product1.setRole("ROLE_NORMAL");
		product1.setUsername("john");
		product1.setPwd(this.bcryptpasswordencoder.encode("durgesh"));

		this.productRepository.save(product1);
		
		
	}
	
	

}
