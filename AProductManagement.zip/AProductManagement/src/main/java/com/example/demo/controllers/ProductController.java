package com.example.demo.controllers;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.Product;
import com.example.demo.sevices.ProductService;




@RestController
public class ProductController {
	
	@RequestMapping(value="/test",method=RequestMethod.GET)
	@ResponseBody
	public String TestM() {
		return "ppp";
	}
	
	@GetMapping(value="/test1")
	//@ResponseBody
	public List<Product> getAll() {
		return this.productService.getAllProducts();
	}
	
	@Autowired
	private ProductService productService;
	
	//return all products
	//@RequestMapping(value="/products",method=RequestMethod.GET)
	//public List<Product> getAllProducts(){
		
		//return this.productService.getAllProducts();
	//}
	
	//returns single product
	@GetMapping("/test1/{pname}")
	public Product getProduct(@PathVariable("pname")String pname) {
		return this.productService.getProduct(pname);
	}
	
	//add a product
	@PostMapping("/test1")
	public Product addProduct(@RequestBody Product product) {
		return this.productService.addProduct(product);
	}
	

}
