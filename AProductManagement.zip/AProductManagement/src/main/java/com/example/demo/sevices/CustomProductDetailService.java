package com.example.demo.sevices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.models.CustomProductDetail;
import com.example.demo.models.Product;
import com.example.demo.repo.ProductRepository;

@Service
public class CustomProductDetailService implements UserDetailsService {
	
	
	@Autowired
	private ProductRepository productrepository;
	

	@Override
	public UserDetails loadUserByUsername(String  username) throws UsernameNotFoundException {
	
		Product product=this.productrepository.findByUsername(username);
		
		if(product==null) {
			throw new UsernameNotFoundException("no user");
		}
		return new CustomProductDetail(product);
	}

}
