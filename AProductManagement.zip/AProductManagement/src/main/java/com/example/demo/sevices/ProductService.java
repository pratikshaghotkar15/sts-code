package com.example.demo.sevices;

import java.util.ArrayList;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.models.Product;


@Service
public class ProductService {
	
	List<Product> list=new ArrayList<>();

	public ProductService() {
		list.add(new Product(11,"oil",2,400,"ADMIN","roshni","abc"));
		list.add(new Product(12,"soap",10,150,"ADMIN","roshni","abc"));
	}
	
	//get single product
	public Product getProduct(String pname) {
		return this.list.stream().filter((product)->product.getPname().equals(pname)).findAny().orElse(null);
	}
	
	//get all products
	
	public List<Product> getAllProducts() {
		return this.list;
	}
	
	//add product
	
	public Product addProduct(Product product) {
		this.list.add(product);
		return product;
		
	}
	
	

}
