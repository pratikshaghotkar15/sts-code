package com.example.demo.service;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.demo.entity.*;
@Service
public class BookService {

	private static List<Book> list=new ArrayList<>();
	
	static {
		list.add(new Book(12,"python","abc"));
		list.add(new Book(13,".net","def"));
		list.add(new Book(14,"angular","ghi"));
	}
	
	public List<Book> getAllBooks(){
		return list;
	}
	
	public Book getBookById(int id) {
		Book book=null;
		book=list.stream().filter(e->e.getId()==id).findFirst().get();
		return book;
	}
	
	public Book addbook(Book b) {
		list.add(b);
		return b;
	}
	
	public void deletebook(int bid) {
		//list=list.stream().filter(book->{
			//if(book.getId()!=bid)
			//{
				//return true;
			//}else {
				//return false;
			//}
		//}).collect(Collectors.toList())	;
		
		list=list.stream().filter(book->book.getId()!=bid).collect(Collectors.toList());
	}
	
	


	public void updateBook(Book book, int bookId)
	{
		list=list.stream().map(b->{
			if(b.getId()==bookId)
			{
				b.setTitle(book.getTitle());
				b.setAuthor(b.getAuthor());
			}
			return b;
		}).collect(Collectors.toList());
		
	}
	}
