package MyFirstBootProject;

import org.springframework.stereotype.Component;

@Component
public class Address {
	
	private String addline;
	private int pin;
	public String getAddline() {
		return addline;
	}
	public void setAddline(String addline) {
		this.addline = addline;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	
	public void display() {
		System.out.println("obj is created");
	}

}
