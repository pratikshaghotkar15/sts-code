package MyFirstBootProject;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Test {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ConfigurableApplicationContext context=SpringApplication.run(Test.class, args);
		Customer c=context.getBean(Customer.class);
		c.display();

	}

}
