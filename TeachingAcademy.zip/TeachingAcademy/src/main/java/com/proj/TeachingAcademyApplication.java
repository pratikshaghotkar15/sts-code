package com.proj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeachingAcademyApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeachingAcademyApplication.class, args);
	}

}
