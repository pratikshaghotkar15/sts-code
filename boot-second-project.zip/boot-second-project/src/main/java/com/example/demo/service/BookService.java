package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Book;
import com.example.demo.repository.BookRepository;

@Service
public class BookService {
    @Autowired
	private BookRepository bookrepository;
	
	public List<Book> getAllBooks(){
		List <Book> list=(List<Book>)this.bookrepository.findAll();
		return list;
	}
	
	public Book getBookById(int id) {
		Book book=null;
		try {
			book=this.bookrepository.findById(id);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return book;
	}
	
	public Book addBook(Book b) {
		bookrepository.save(b);
		return b;
	}
	
	public void deleteBook(int id) {
		bookrepository.deleteById(id);
	}
	
	public void updateBook(Book book,int bookId ) {
		book.setId(bookId);
		bookrepository.save(book);
		
	}
}
