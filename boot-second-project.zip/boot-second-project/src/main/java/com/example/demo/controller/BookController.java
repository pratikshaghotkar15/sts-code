package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.*;
import com.example.demo.service.*;

@RestController
public class BookController {
    @Autowired
	private BookService bookservice;
	//@GetMapping("/books")
	//public Book getBooks() {
		//Book book=new Book();
		//book.setId(1124);
		//book.setTitle("java");
		//book.setAuthor("xyz");
		//return book;
		
	//}
	
	@GetMapping("/books")
	public List<Book> getBooks() {
		return this.bookservice.getAllBooks();
	}
	
	@GetMapping("/books/{id}")
	public Book getBook(@PathVariable("id")int id) {
		
		return bookservice.getBookById(id);
		
	}
	
	@PostMapping("/books")
	//RequestBody (obj b from service in json format)
	public Book addBook(@RequestBody Book book) {
	Book b=this.bookservice.addBook(book);
	return b;
	}
	
	@DeleteMapping("/books/{bookId}")
	public void deleteBook(@PathVariable("bookId")int bookId) {
		this.bookservice.deleteBook(bookId);
	}
	
	
	@PutMapping("/books/{bId}")
	public Book updateBook(@RequestBody Book book,@PathVariable("bId")int bId)
	{
		this.bookservice.updateBook(book,bId);
		return book;
	}
}
