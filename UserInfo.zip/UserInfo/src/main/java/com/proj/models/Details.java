package com.proj.models;


public class Details {

}
