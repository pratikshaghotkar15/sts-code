package com.proj.demo.service;


import java.util.Date;
import java.util.List;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.proj.demo.dao.UserDao;
import com.proj.demo.model.User;

@Service
public class UserService {
	
	@Autowired
	private UserDao userdao;
	
	Logger log=LoggerFactory.getLogger(UserService.class);
	
	@Scheduled(fixedRate=5000)
	public void addJob() {
		User user=new User();
		user.setName("user"+new Random().nextInt(374483));
		userdao.save(user);
		System.out.println("add service call"+new Date().toString());
	
	}
	
	@Scheduled(cron="0/15 * * * * *")
	public void fetchJob() {
		List<User> users=userdao.findAll();
		System.out.println("fetch service call"+new Date().toString());
		System.out.println("no of records"+users.size());
		log.info("users :{}",users);
		}
	
	
	
	
	
	

}
