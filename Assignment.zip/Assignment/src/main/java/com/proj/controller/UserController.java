package com.proj.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.proj.entity.User;

@RestController
public class UserController {
	
	@RequestMapping("/hello")
	public String hello() {
		return "hello world";
	}
	
	@GetMapping(value="/callclient")
	private String getClientCall() {
		String uri="http://localhost:8080/hello";
		RestTemplate restTemplate=new RestTemplate();
		String result=restTemplate.getForObject(uri,String.class);
		return result;
	}
	
	@GetMapping(value="/genders")
	public User getDetails() {
		String uri="https://api.genderize.io/?name=peter";
		RestTemplate restTemplate=new RestTemplate();
		User result=restTemplate.getForObject(uri,User.class);
		return result;
	}
	
	

	
}
